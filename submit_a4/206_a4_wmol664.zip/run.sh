#!/bin/bash

/usr/lib/jvm/jdk1.8.0_91/bin/java -jar "./VoxSpell.jar" &> /dev/null
