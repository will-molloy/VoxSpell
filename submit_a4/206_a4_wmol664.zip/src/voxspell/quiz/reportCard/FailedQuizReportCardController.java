package voxspell.quiz.reportCard;

/**
 * Controller for the report card shown when the user fails a quiz.
 *
 * @author Will Molloy
 */
public class FailedQuizReportCardController extends ReportCardController {

    /*
    I had stuff here but changed the implementation later on..
     */
    @Override
    public void createGUI() {
    }

}
