package voxspell.quiz.reportCard;

/**
 * Returns the PassedQuizReport FXML.
 */
public class PassedQuizReportCardFactory extends ReportCardFactory {

    @Override
    String getFXML() {
        return "Passed_Quiz_Report.fxml";
    }
}
