package voxspell.quiz.reportCard;

/**
 * Returns the FailedQuizReport FXML.
 */
public class FailedQuizReportCardFactory extends ReportCardFactory {

    @Override
    String getFXML() {
        return "Failed_Quiz_Report.fxml";
    }
}
